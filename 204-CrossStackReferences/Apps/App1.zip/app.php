<html>
 <head>
  <title>Cody's Amazing PHP App</title>
 </head>
 <body>
 <?php echo '<p>Hello World - Working - Version 1</p>'; ?>
 </body>
</html>
